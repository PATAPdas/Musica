# Onda

Tu propio reproductor para Android con tu cuenta de Spotify Premium: inicio, búsqueda, biblioteca, listas, álbumes, artistas, canciones que te gustan y una pantalla de "Reproduciendo" con controles.

La música es la de tu Spotify y suena a través de la app oficial de Spotify instalada en el móvil (Spotify Connect). Onda no descarga ni copia canciones.

## 1. Conseguir el APK (GitHub lo compila)

1. Crea una cuenta en [github.com](https://github.com) si no tienes.
2. Pulsa **New repository**, ponle de nombre `onda`, elige **Private** y créalo **sin** README.
3. En la página del repositorio vacío, pulsa **uploading an existing file**.
4. Descomprime `Onda-proyecto.zip` en tu ordenador y arrastra **todo el contenido de la carpeta** a la página (también la carpeta `.github`; si tu sistema la oculta, activa "mostrar archivos ocultos"). Pulsa **Commit changes**.
5. Ve a la pestaña **Actions**. Verás "Compilar APK" en marcha. Tarda unos 3–5 minutos.
6. Cuando salga en verde, ve a **Releases** (columna derecha de la página principal) → **Onda (última versión)** → descarga **Onda.apk** desde el móvil.
7. Ábrelo en el móvil. Android te pedirá permiso para "instalar apps de origen desconocido" desde el navegador: acéptalo.

Si la compilación sale en rojo, abre el paso que falla, copia el error y pásamelo.

## 2. Conectar con tu Spotify (solo la primera vez)

1. Entra en [developer.spotify.com/dashboard](https://developer.spotify.com/dashboard) con tu cuenta Premium y pulsa **Create app**.
2. Nombre y descripción: lo que quieras (por ejemplo "Onda").
3. En **Redirect URIs** añade exactamente: `http://127.0.0.1:8888/callback`
4. Marca **Web API**, acepta las condiciones y guarda.
5. Abre la app, entra en **Settings** y copia el **Client ID**.
6. Abre Onda en el móvil, pega el Client ID y pulsa **Iniciar sesión con Spotify**. Entra con tu correo y contraseña (el botón "Continuar con Google" no funciona dentro de apps).

## 3. Uso

- Toca cualquier canción, lista o álbum para reproducirlo.
- Si Onda dice que no encuentra tu Spotify, abre la app de Spotify un momento y vuelve: así el móvil aparece como dispositivo.
- Toca la barra de abajo para abrir "Reproduciendo" (aleatorio, repetir, me gusta, elegir dispositivo).
- Puedes mandar la música a otro dispositivo (portátil, altavoz) desde el botón de dispositivos.

## Límites (los pone Spotify)

- Hace falta **Spotify Premium** para controlar la reproducción, y la cuenta dueña de la app del dashboard debe tener Premium.
- Una app en modo desarrollo admite como mucho 5 usuarios (los añades en *User Management* del dashboard).
- Solo se ven las canciones de las listas que son tuyas o en las que colaboras. Las demás se pueden reproducir enteras.
- La búsqueda devuelve hasta 10 resultados por tipo.

## Estructura

```
app/src/main/assets/        Interfaz (index.html, style.css, app.js)
app/src/main/java/...       MainActivity: WebView, login y apertura de Spotify
.github/workflows/build.yml Compilación automática del APK
```

Onda es un proyecto personal y no es un producto de Spotify. Contenido y metadatos de Spotify.
