plugins {
    id("com.android.application")
}

android {
    namespace = "com.pau.onda"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.pau.onda"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    // Clave fija para que cada APK nuevo se instale encima del anterior sin desinstalar.
    // Es una clave de depuración (contraseña "android"), solo para uso personal.
    signingConfigs {
        getByName("debug") {
            storeFile = file("onda-debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }

    buildTypes {
        getByName("debug") {
            signingConfig = signingConfigs.getByName("debug")
        }
        getByName("release") {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
