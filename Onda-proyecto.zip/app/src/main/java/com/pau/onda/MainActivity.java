package com.pau.onda;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

/**
 * Onda: muestra la interfaz (assets/) en un WebView servido desde un origen https propio,
 * intercepta la vuelta del login de Spotify y abre la app oficial de Spotify cuando hace falta.
 */
public class MainActivity extends Activity {

    private static final String APP_HOST = "app.local";
    private static final String APP_URL = "https://app.local/index.html";
    private static final String REDIRECT_PREFIX = "http://127.0.0.1:8888/callback";

    private WebView web;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        web = new WebView(this);
        web.setBackgroundColor(Color.parseColor("#0f0f14"));
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setMediaPlaybackRequiresUserGesture(false);

        web.setWebViewClient(new OndaClient());
        web.addJavascriptInterface(new Bridge(), "Android");
        setContentView(web);

        if (savedInstanceState != null) {
            web.restoreState(savedInstanceState);
        } else {
            web.loadUrl(APP_URL);
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        web.saveState(outState);
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        if (web != null && web.canGoBack()) {
            web.goBack();
        } else {
            super.onBackPressed();
        }
    }

    private static String appUrlWithQuery(Uri callback) {
        String q = callback.getEncodedQuery();
        return APP_URL + (q != null && !q.isEmpty() ? "?" + q : "");
    }

    private class OndaClient extends WebViewClient {

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
            Uri uri = request.getUrl();
            String url = uri.toString();
            if (url.startsWith(REDIRECT_PREFIX)) {
                view.loadUrl(appUrlWithQuery(uri));
                return true;
            }
            String scheme = uri.getScheme() == null ? "" : uri.getScheme();
            if (scheme.equals("http") || scheme.equals("https")) {
                return false;
            }
            // spotify:, intent:, market:, mailto: ... se abren fuera
            openExternal(uri);
            return true;
        }

        @Override
        public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
            Uri uri = request.getUrl();
            String url = uri.toString();

            // Vuelta del login de Spotify: se redirige a la app con el código
            if (url.startsWith(REDIRECT_PREFIX)) {
                String html = "<!doctype html><meta charset=utf-8><script>location.replace("
                        + JSONObject.quote(appUrlWithQuery(uri)) + ");</script>";
                return new WebResourceResponse("text/html", "utf-8",
                        new ByteArrayInputStream(html.getBytes(StandardCharsets.UTF_8)));
            }

            // Archivos de la interfaz servidos desde assets/
            if (APP_HOST.equals(uri.getHost())) {
                String path = uri.getPath();
                if (path == null || path.equals("/") || path.isEmpty()) path = "/index.html";
                path = path.substring(1);
                if (path.contains("..")) return notFound();
                try {
                    InputStream in = getAssets().open(path);
                    Map<String, String> headers = new HashMap<>();
                    headers.put("Cache-Control", "no-cache");
                    return new WebResourceResponse(mime(path), "utf-8", 200, "OK", headers, in);
                } catch (IOException e) {
                    return notFound();
                }
            }
            return null;
        }
    }

    private static WebResourceResponse notFound() {
        return new WebResourceResponse("text/plain", "utf-8", 404, "Not Found",
                new HashMap<String, String>(), new ByteArrayInputStream(new byte[0]));
    }

    private static String mime(String path) {
        if (path.endsWith(".html")) return "text/html";
        if (path.endsWith(".js")) return "application/javascript";
        if (path.endsWith(".css")) return "text/css";
        if (path.endsWith(".svg")) return "image/svg+xml";
        if (path.endsWith(".png")) return "image/png";
        if (path.endsWith(".json")) return "application/json";
        return "application/octet-stream";
    }

    private void openExternal(Uri uri) {
        try {
            Intent i = new Intent(Intent.ACTION_VIEW, uri);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (ActivityNotFoundException e) {
            if ("spotify".equals(uri.getScheme())) {
                openStore();
            }
        }
    }

    private void openStore() {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=com.spotify.music"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        } catch (ActivityNotFoundException e) {
            startActivity(new Intent(Intent.ACTION_VIEW,
                    Uri.parse("https://play.google.com/store/apps/details?id=com.spotify.music"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        }
    }

    /** Puente que la interfaz llama como window.Android.* */
    private class Bridge {
        @JavascriptInterface
        public void openSpotify(final String spotifyUri) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    String target = (spotifyUri == null || spotifyUri.isEmpty()) ? "spotify:" : spotifyUri;
                    if (!target.startsWith("spotify:")) target = "spotify:";
                    Intent launch = getPackageManager().getLaunchIntentForPackage("com.spotify.music");
                    if (target.equals("spotify:") && launch != null) {
                        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(launch);
                    } else {
                        openExternal(Uri.parse(target));
                    }
                }
            });
        }

        @JavascriptInterface
        public boolean hasSpotify() {
            return getPackageManager().getLaunchIntentForPackage("com.spotify.music") != null;
        }
    }
}
