/* Onda: un reproductor propio para tu cuenta de Spotify.
 * Toda la música se reproduce a través de la app oficial de Spotify (Spotify Connect).
 * Usa la Web API de Spotify con OAuth PKCE (sin servidor ni secreto de cliente). */
'use strict';

const REDIRECT_URI = 'http://127.0.0.1:8888/callback';
const API = 'https://api.spotify.com/v1';
const SCOPES = [
  'user-read-private',
  'user-read-playback-state',
  'user-modify-playback-state',
  'user-read-currently-playing',
  'user-read-recently-played',
  'user-library-read',
  'user-library-modify',
  'playlist-read-private',
  'playlist-read-collaborative',
  'user-follow-read'
].join(' ');

/* ---------- Almacenamiento seguro ---------- */
const store = {
  get(k) { try { return localStorage.getItem('onda.' + k); } catch (e) { return null; } },
  set(k, v) { try { localStorage.setItem('onda.' + k, v); } catch (e) {} },
  del(k) { try { localStorage.removeItem('onda.' + k); } catch (e) {} }
};

/* ---------- Iconos ---------- */
const ICONS = {
  home: '<path d="M12 3 2 11.5h3V21h5.5v-6h3v6H19v-9.5h3z"/>',
  search: '<path d="M10.5 3a7.5 7.5 0 0 1 5.96 12.05l4.74 4.74-1.41 1.41-4.74-4.74A7.5 7.5 0 1 1 10.5 3zm0 2a5.5 5.5 0 1 0 0 11 5.5 5.5 0 0 0 0-11z"/>',
  library: '<path d="M4 3h2v18H4zm5 0h2v18H9zm4.6.7 1.9-.6 5.6 17.2-1.9.6z"/>',
  play: '<path d="M8 5v14l11-7z"/>',
  pause: '<path d="M6 5h4v14H6zm8 0h4v14h-4z"/>',
  next: '<path d="M6 6v12l8.5-6zM16 6h2v12h-2z"/>',
  prev: '<path d="M18 6v12l-8.5-6zM6 6h2v12H6z"/>',
  shuffle: '<path d="M17 3l4 4-4 4V8h-2.6l-3.1 4 3.1 4H17v-3l4 4-4 4v-3h-3.6l-3.6-4.7L6.2 18H3v-2h2.2l3.1-4-3.1-4H3V6h3.2l3.6 4.7L13.4 6H17z"/>',
  repeat: '<path d="M7 7h10v3l4-4-4-4v3H5v6h2zm10 10H7v-3l-4 4 4 4v-3h12v-6h-2z"/>',
  repeatOne: '<path d="M7 7h10v3l4-4-4-4v3H5v6h2zm10 10H7v-3l-4 4 4 4v-3h12v-6h-2zm-4-2V9h-1l-2 1v1h1.5v4z"/>',
  heart: '<path d="M12 21s-7.5-4.6-9.5-9.3C1.1 8.3 3.3 4.5 7 4.5c2 0 3.4 1.1 5 3 1.6-1.9 3-3 5-3 3.7 0 5.9 3.8 4.5 7.2C19.5 16.4 12 21 12 21zm0-2.4c2.6-1.7 6.2-4.5 7.6-7.7.9-2.1-.5-4.4-2.6-4.4-1.4 0-2.4.9-4.2 3.1h-1.6C9.4 7.4 8.4 6.5 7 6.5c-2.1 0-3.5 2.3-2.6 4.4 1.4 3.2 5 6 7.6 7.7z"/>',
  heartFill: '<path d="M12 21s-7.5-4.6-9.5-9.3C1.1 8.3 3.3 4.5 7 4.5c2 0 3.4 1.1 5 3 1.6-1.9 3-3 5-3 3.7 0 5.9 3.8 4.5 7.2C19.5 16.4 12 21 12 21z"/>',
  down: '<path d="M7.4 8.6 12 13.2l4.6-4.6L18 10l-6 6-6-6z"/>',
  back: '<path d="M20 11H7.8l5.6-5.6L12 4l-8 8 8 8 1.4-1.4L7.8 13H20z"/>',
  devices: '<path d="M3 5h12v2H5v10h10v2H3zm14 0h4v14h-4zm2 10.5a1 1 0 1 0 0 2 1 1 0 0 0 0-2z"/>',
  wave: '<path d="M3 13h2v-2H3zm4 4h2V7H7zm4 3h2V4h-2zm4-3h2V7h-2zm4-4h2v-2h-2z"/>',
  gear: '<path d="M19.4 13a7.5 7.5 0 0 0 0-2l2.1-1.6-2-3.5-2.5 1a7.4 7.4 0 0 0-1.7-1L15 3.3h-4l-.4 2.6a7.4 7.4 0 0 0-1.7 1l-2.5-1-2 3.5L6.6 11a7.5 7.5 0 0 0 0 2l-2.1 1.6 2 3.5 2.5-1c.5.4 1.1.7 1.7 1l.4 2.6h4l.4-2.6c.6-.3 1.2-.6 1.7-1l2.5 1 2-3.5zM13 15.5a3.5 3.5 0 1 1 0-7 3.5 3.5 0 0 1 0 7z" transform="translate(-1 0)"/>'
};
const icon = (name) => '<svg viewBox="0 0 24 24" aria-hidden="true">' + (ICONS[name] || '') + '</svg>';

/* ---------- Utilidades ---------- */
const $ = (sel) => document.querySelector(sel);
const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const fmt = (ms) => { const s = Math.max(0, Math.floor((ms || 0) / 1000)); return Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0'); };
const img = (images, size) => {
  if (!images || !images.length) return '';
  const sorted = images.slice().sort((a, b) => (a.width || 0) - (b.width || 0));
  const pick = sorted.find((i) => (i.width || 640) >= (size || 300)) || sorted[sorted.length - 1];
  return pick.url;
};
const plain = (html) => { const t = document.createElement('textarea'); t.innerHTML = String(html).replace(/<[^>]*>/g, ''); return t.value; };
const artists = (list) => (list || []).map((a) => a.name).join(', ');
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const isAndroid = () => typeof window.Android !== 'undefined';

let toastTimer;
function toast(msg) {
  const t = $('#toast');
  t.textContent = msg;
  t.classList.remove('hidden');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => t.classList.add('hidden'), 3500);
}

function openSpotify(uri) {
  if (isAndroid()) { window.Android.openSpotify(uri || ''); return; }
  const id = uri ? uri.split(':').pop() : '';
  const type = uri ? uri.split(':')[1] : '';
  window.open(uri ? 'https://open.spotify.com/' + type + '/' + id : 'https://open.spotify.com', '_blank');
}

/* ---------- Autenticación (PKCE) ---------- */
function randomString(len) {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  const bytes = crypto.getRandomValues(new Uint8Array(len));
  return Array.from(bytes, (b) => chars[b % chars.length]).join('');
}
async function sha256b64url(text) {
  const digest = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(text));
  return btoa(String.fromCharCode(...new Uint8Array(digest))).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

async function login() {
  const clientId = store.get('clientId');
  if (!clientId) { renderSetup(); return; }
  const verifier = randomString(64);
  const state = randomString(16);
  store.set('verifier', verifier);
  store.set('state', state);
  const params = new URLSearchParams({
    client_id: clientId,
    response_type: 'code',
    redirect_uri: REDIRECT_URI,
    scope: SCOPES,
    code_challenge_method: 'S256',
    code_challenge: await sha256b64url(verifier),
    state: state
  });
  location.href = 'https://accounts.spotify.com/authorize?' + params.toString();
}

function saveTokens(data) {
  store.set('access', data.access_token);
  store.set('expires', String(Date.now() + (data.expires_in - 60) * 1000));
  if (data.refresh_token) store.set('refresh', data.refresh_token);
}

async function tokenRequest(body) {
  const res = await fetch('https://accounts.spotify.com/api/token', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams(body).toString()
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error_description || data.error || ('Error ' + res.status));
  saveTokens(data);
}

async function handleCallback() {
  const q = new URLSearchParams(location.search);
  if (!q.has('code') && !q.has('error')) return false;
  history.replaceState(null, '', location.pathname + '#/home');
  if (q.get('error')) { renderSetup('Spotify ha cancelado el acceso: ' + q.get('error')); return true; }
  if (q.get('state') !== store.get('state')) { renderSetup('La respuesta de Spotify no coincide. Vuelve a intentarlo.'); return true; }
  try {
    await tokenRequest({
      grant_type: 'authorization_code',
      code: q.get('code'),
      redirect_uri: REDIRECT_URI,
      client_id: store.get('clientId'),
      code_verifier: store.get('verifier')
    });
  } catch (e) {
    renderSetup('No se pudo iniciar sesión: ' + e.message);
    return true;
  }
  store.del('verifier'); store.del('state');
  return false;
}

let refreshing = null;
async function refreshToken() {
  const rt = store.get('refresh');
  if (!rt) throw new Error('NO_SESSION');
  if (!refreshing) {
    refreshing = tokenRequest({ grant_type: 'refresh_token', refresh_token: rt, client_id: store.get('clientId') })
      .finally(() => { refreshing = null; });
  }
  return refreshing;
}

function logout() {
  ['access', 'refresh', 'expires', 'deviceId'].forEach(store.del);
  stopPolling();
  renderSetup();
}

/* ---------- Cliente de la API ---------- */
class ApiError extends Error {
  constructor(status, message, reason) { super(message); this.status = status; this.reason = reason; }
}

async function api(path, opts = {}, retried = false) {
  if (!store.get('access') || Date.now() > Number(store.get('expires') || 0)) {
    try { await refreshToken(); } catch (e) { logout(); throw new ApiError(401, 'Sesión caducada'); }
  }
  const res = await fetch(path.startsWith('http') ? path : API + path, {
    method: opts.method || 'GET',
    headers: Object.assign({ Authorization: 'Bearer ' + store.get('access') }, opts.body ? { 'Content-Type': 'application/json' } : {}),
    body: opts.body ? JSON.stringify(opts.body) : undefined
  });
  if (res.status === 401 && !retried) {
    try { await refreshToken(); } catch (e) { logout(); throw new ApiError(401, 'Sesión caducada'); }
    return api(path, opts, true);
  }
  if (res.status === 429 && !retried) {
    await sleep((Number(res.headers.get('Retry-After')) || 2) * 1000);
    return api(path, opts, true);
  }
  if (res.status === 204 || res.status === 202) return null;
  const text = await res.text();
  let data = null;
  try { data = text ? JSON.parse(text) : null; } catch (e) { data = null; }
  if (!res.ok) {
    const err = (data && data.error) || {};
    throw new ApiError(res.status, err.message || ('Error ' + res.status), err.reason);
  }
  return data;
}

/* ---------- Pantalla de configuración ---------- */
function renderSetup(error) {
  setTab(null);
  document.body.classList.add('setup-mode');
  $('#tabs').classList.add('hidden');
  $('#mini').classList.add('hidden');
  const clientId = store.get('clientId') || '';
  $('#view').innerHTML = `
    <div class="setup">
      <div class="logo">${icon('wave')}</div>
      <h1>Bienvenido a Onda</h1>
      <p class="muted">Tu propio reproductor para tu cuenta de Spotify Premium. La música suena a través de la app de Spotify de tu móvil.</p>
      ${error ? `<div class="note" style="color:var(--danger)">${esc(error)}</div>` : ''}
      <h2>Configuración (solo la primera vez)</h2>
      <ol>
        <li>Entra en <a class="link" href="https://developer.spotify.com/dashboard" target="_blank">developer.spotify.com/dashboard</a> con tu cuenta y pulsa <b>Create app</b>.</li>
        <li>En <b>Redirect URIs</b> añade exactamente:<br><code>${REDIRECT_URI}</code></li>
        <li>Marca <b>Web API</b>, acepta las condiciones y guarda.</li>
        <li>Copia el <b>Client ID</b> de la app y pégalo aquí:</li>
      </ol>
      <input id="cid" class="field" placeholder="Client ID" value="${esc(clientId)}" autocomplete="off" autocapitalize="off" spellcheck="false">
      <button id="go" class="btn">Iniciar sesión con Spotify</button>
      <p class="muted" style="font-size:12px;margin-top:18px">Inicia sesión con tu correo y contraseña de Spotify (el botón de Google no funciona dentro de apps). Onda no es un producto de Spotify. El contenido musical y los metadatos los proporciona Spotify.</p>
    </div>`;
  $('#go').onclick = () => {
    const v = $('#cid').value.trim();
    if (!/^[a-f0-9]{32}$/i.test(v)) { toast('El Client ID son 32 letras y números. Revisa que esté bien copiado.'); return; }
    store.set('clientId', v);
    login();
  };
}

/* ---------- Router ---------- */
const routes = {
  home: renderHome,
  search: renderSearch,
  library: renderLibrary,
  playlist: renderPlaylist,
  album: renderAlbum,
  artist: renderArtist,
  liked: renderLiked,
  settings: renderSettings
};
let me = null;
let renderToken = 0;
let currentRoute = '';

function setTab(name) {
  document.querySelectorAll('#tabs a').forEach((a) => a.classList.toggle('active', a.dataset.tab === name));
}

async function route() {
  if (!store.get('refresh')) { renderSetup(); return; }
  document.body.classList.remove('setup-mode');
  $('#tabs').classList.remove('hidden');
  currentRoute = (location.hash || '#/home').split('?')[0];
  const parts = currentRoute.slice(2).split('/');
  const name = routes[parts[0]] ? parts[0] : 'home';
  setTab(['home', 'search', 'library'].includes(name) ? name : null);
  closeNowPlaying(true);
  const token = ++renderToken;
  window.scrollTo(0, 0);
  try {
    await routes[name](parts[1] ? decodeURIComponent(parts[1]) : null, token);
  } catch (e) {
    if (token !== renderToken) return;
    if (e.status === 401) return;
    $('#view').innerHTML = `<div class="empty">No se pudo cargar.<br><span style="font-size:13px">${esc(e.message)}</span><br><br><button class="btn ghost" onclick="route()">Reintentar</button></div>`;
  }
}

const loading = () => { $('#view').innerHTML = '<div class="skeleton" style="width:50%;height:28px"></div>' + '<div class="skeleton"></div>'.repeat(6); };
const backBtn = () => `<button class="icon-btn back" onclick="history.back()" aria-label="Atrás">${icon('back')}</button>`;

/* ---------- Piezas de la interfaz ---------- */
function trackRow(t, opts = {}) {
  if (!t) return '';
  const playing = player.state && player.state.item && player.state.item.id === t.id;
  const art = opts.noArt ? `<div class="track-num">${opts.num || ''}</div>` : `<img src="${esc(img(t.album && t.album.images, 64))}" alt="" loading="lazy">`;
  return `<div class="row${playing ? ' playing' : ''}" data-id="${esc(t.id)}" data-play='${esc(JSON.stringify(opts.play || { uris: [t.uri] }))}'>
    ${art}
    <div class="txt"><div class="t ellipsis">${esc(t.name)}</div><div class="s muted ellipsis">${t.explicit ? 'E · ' : ''}${esc(artists(t.artists))}</div></div>
    <div class="muted" style="font-size:12px">${fmt(t.duration_ms)}</div>
  </div>`;
}

function tile(item, kind) {
  if (!item) return '';
  const href = '#/' + kind + '/' + item.id;
  const sub = kind === 'album' ? artists(item.artists) : kind === 'artist' ? 'Artista' : (item.owner && item.owner.display_name ? 'De ' + item.owner.display_name : 'Lista');
  return `<a class="tile${kind === 'artist' ? ' round' : ''}" href="${href}">
    <img src="${esc(img(item.images, 300))}" alt="" loading="lazy">
    <div class="t ellipsis">${esc(item.name)}</div><div class="s muted ellipsis">${esc(sub)}</div></a>`;
}

function listRow(item, kind) {
  const sub = kind === 'album' ? 'Álbum · ' + artists(item.artists) : kind === 'artist' ? 'Artista' : 'Lista · ' + ((item.owner && item.owner.display_name) || '');
  return `<a class="row" href="#/${kind}/${item.id}">
    <img class="${kind === 'artist' ? 'round' : ''}" src="${esc(img(item.images, 64))}" alt="" loading="lazy">
    <div class="txt"><div class="t ellipsis">${esc(item.name)}</div><div class="s muted ellipsis">${esc(sub)}</div></div></a>`;
}

const likedArt = (size) => `<div class="liked-art" style="width:${size}px;height:${size}px;border-radius:${size > 100 ? 8 : 6}px;flex:none">${icon('heartFill')}</div>`;

// Delegación: tocar una fila de canción la reproduce
document.addEventListener('click', (ev) => {
  const row = ev.target.closest('[data-play]');
  if (!row) return;
  try { player.play(JSON.parse(row.getAttribute('data-play'))); } catch (e) {}
});

/* ---------- Inicio ---------- */
async function renderHome(_, token) {
  loading();
  const h = new Date().getHours();
  const hello = h < 6 ? 'Buenas noches' : h < 14 ? 'Buenos días' : h < 21 ? 'Buenas tardes' : 'Buenas noches';
  const [playlists, recent] = await Promise.all([
    api('/me/playlists?limit=30'),
    api('/me/player/recently-played?limit=30').catch(() => ({ items: [] }))
  ]);
  if (token !== renderToken) return;
  const pls = (playlists && playlists.items || []).filter(Boolean);
  const seen = new Set();
  const recentTracks = (recent.items || []).map((i) => i.track).filter((t) => t && !seen.has(t.id) && seen.add(t.id));
  $('#view').innerHTML = `
    <div style="display:flex;align-items:center;justify-content:space-between">
      <h1>${hello}</h1>
      <a class="icon-btn" href="#/settings" aria-label="Ajustes">${icon('gear')}</a>
    </div>
    <div class="quick">
      <a href="#/liked">${likedArt(56)}<span class="ellipsis">Canciones que te gustan</span></a>
      ${pls.slice(0, 5).map((p) => `<a href="#/playlist/${p.id}"><img src="${esc(img(p.images, 64))}" alt=""><span class="ellipsis">${esc(p.name)}</span></a>`).join('')}
    </div>
    ${recentTracks.length ? `<h2>Escuchado recientemente</h2>
      <div class="shelf">${recentTracks.slice(0, 15).map((t) => `
        <div class="tile" data-play='${esc(JSON.stringify({ uris: [t.uri] }))}'>
          <img src="${esc(img(t.album.images, 300))}" alt="" loading="lazy">
          <div class="t ellipsis">${esc(t.name)}</div><div class="s muted ellipsis">${esc(artists(t.artists))}</div>
        </div>`).join('')}</div>` : ''}
    ${pls.length ? `<h2>Tus listas</h2><div class="shelf">${pls.map((p) => tile(p, 'playlist')).join('')}</div>` : ''}
    ${recentTracks.length > 15 ? `<h2>Más de lo que escuchas</h2>${recentTracks.slice(15).map((t) => trackRow(t)).join('')}` : ''}
  `;
}

/* ---------- Buscar ---------- */
let searchTimer;
let lastQuery = '';
async function renderSearch(_, token) {
  $('#view').innerHTML = `
    <h1>Buscar</h1>
    <div class="search-box"><input id="q" type="search" placeholder="¿Qué te apetece escuchar?" value="${esc(lastQuery)}" autocomplete="off"></div>
    <div id="results"></div>`;
  const input = $('#q');
  input.addEventListener('input', () => {
    clearTimeout(searchTimer);
    searchTimer = setTimeout(() => doSearch(input.value.trim()), 400);
  });
  if (lastQuery) doSearch(lastQuery); else { $('#results').innerHTML = '<div class="empty">Busca canciones, artistas, álbumes o listas.</div>'; input.focus(); }
}

async function doSearch(q) {
  lastQuery = q;
  const box = $('#results');
  if (!box) return;
  if (!q) { box.innerHTML = ''; return; }
  box.innerHTML = '<div class="skeleton"></div>'.repeat(4);
  const r = await api('/search?type=track,artist,album,playlist&limit=10&q=' + encodeURIComponent(q));
  if (q !== lastQuery || !$('#results')) return;
  const tracks = (r.tracks && r.tracks.items || []).filter(Boolean);
  const arts = (r.artists && r.artists.items || []).filter(Boolean);
  const albums = (r.albums && r.albums.items || []).filter(Boolean);
  const pls = (r.playlists && r.playlists.items || []).filter(Boolean);
  if (!tracks.length && !arts.length && !albums.length && !pls.length) { box.innerHTML = '<div class="empty">Sin resultados.</div>'; return; }
  box.innerHTML = `
    ${tracks.length ? '<h2>Canciones</h2>' + tracks.map((t) => trackRow(t)).join('') : ''}
    ${arts.length ? '<h2>Artistas</h2><div class="shelf">' + arts.map((a) => tile(a, 'artist')).join('') + '</div>' : ''}
    ${albums.length ? '<h2>Álbumes</h2><div class="shelf">' + albums.map((a) => tile(a, 'album')).join('') + '</div>' : ''}
    ${pls.length ? '<h2>Listas</h2><div class="shelf">' + pls.map((p) => tile(p, 'playlist')).join('') + '</div>' : ''}`;
}

/* ---------- Biblioteca ---------- */
let libFilter = 'playlists';
async function renderLibrary(_, token) {
  loading();
  const data = libFilter === 'albums' ? await api('/me/albums?limit=50') : await api('/me/playlists?limit=50');
  if (token !== renderToken) return;
  const items = (data.items || []).filter(Boolean);
  $('#view').innerHTML = `
    <h1>Tu biblioteca</h1>
    <div class="chips">
      <button class="chip ${libFilter === 'playlists' ? 'on' : ''}" data-f="playlists">Listas</button>
      <button class="chip ${libFilter === 'albums' ? 'on' : ''}" data-f="albums">Álbumes</button>
    </div>
    ${libFilter === 'playlists' ? `<a class="row" href="#/liked">${likedArt(52)}<div class="txt"><div class="t">Canciones que te gustan</div><div class="s muted">Lista</div></div></a>` : ''}
    ${items.map((i) => libFilter === 'albums' ? listRow(i.album, 'album') : listRow(i, 'playlist')).join('') || '<div class="empty">Aquí no hay nada todavía.</div>'}
    ${data.next ? '<button id="libMore" class="btn ghost more">Cargar más</button>' : ''}`;
  document.querySelectorAll('.chip').forEach((c) => c.onclick = () => { libFilter = c.dataset.f; renderLibrary(null, ++renderToken); });
  let next = data.next;
  const more = $('#libMore');
  if (more) more.onclick = async () => {
    more.textContent = 'Cargando…';
    const d = await api(next);
    next = d.next;
    more.insertAdjacentHTML('beforebegin', d.items.filter(Boolean).map((i) => libFilter === 'albums' ? listRow(i.album, 'album') : listRow(i, 'playlist')).join(''));
    if (!next) more.remove(); else more.textContent = 'Cargar más';
  };
}

/* ---------- Lista ---------- */
async function renderPlaylist(id, token) {
  loading();
  const p = await api('/playlists/' + id + '?fields=id,name,description,images,uri,owner(id,display_name),collaborative');
  if (token !== renderToken) return;
  let page = null;
  let blocked = false;
  try { page = await api('/playlists/' + id + '/items?limit=50&additional_types=track'); }
  catch (e) { if (e.status === 403 || e.status === 404) blocked = true; else throw e; }
  if (token !== renderToken) return;
  const rows = (items, start) => items.map((it, i) => {
    const t = it && (it.item || it.track);
    if (!t || it.is_local || t.type !== 'track') return '';
    return trackRow(t, { play: { context_uri: p.uri, offset: { position: start + i } } });
  }).join('');
  $('#view').innerHTML = `
    ${backBtn()}
    <div class="hero">
      <img src="${esc(img(p.images, 300))}" alt="">
      <h1>${esc(p.name)}</h1>
      ${p.description ? `<div class="desc muted">${esc(plain(p.description))}</div>` : ''}
      <div class="muted" style="font-size:13px;margin-top:6px">${esc(p.owner && p.owner.display_name)}${page ? ' · ' + page.total + ' canciones' : ''}</div>
    </div>
    <div class="actions">
      <button class="icon-btn" id="shuf" aria-label="Aleatorio">${icon('shuffle')}</button>
      <span class="spacer"></span>
      <button class="play-btn" data-play='${esc(JSON.stringify({ context_uri: p.uri }))}' aria-label="Reproducir">${icon('play')}</button>
    </div>
    ${blocked ? '<div class="note">Spotify solo deja ver las canciones de las listas que son tuyas o en las que colaboras. Puedes reproducir esta lista entera con el botón de reproducir.</div>' : ''}
    <div id="plRows">${page ? rows(page.items, 0) : ''}</div>
    ${page && page.next ? '<button id="plMore" class="btn ghost more">Cargar más</button>' : ''}`;
  $('#shuf').onclick = () => player.play({ context_uri: p.uri }, true);
  let next = page && page.next;
  let offset = page ? page.items.length : 0;
  const more = $('#plMore');
  if (more) more.onclick = async () => {
    more.textContent = 'Cargando…';
    const d = await api(next);
    $('#plRows').insertAdjacentHTML('beforeend', rows(d.items, offset));
    offset += d.items.length;
    next = d.next;
    if (!next) more.remove(); else more.textContent = 'Cargar más';
  };
}

/* ---------- Álbum ---------- */
async function renderAlbum(id, token) {
  loading();
  const a = await api('/albums/' + id);
  if (token !== renderToken) return;
  const tracks = (a.tracks.items || []).filter(Boolean).map((t) => Object.assign({}, t, { album: a }));
  $('#view').innerHTML = `
    ${backBtn()}
    <div class="hero">
      <img src="${esc(img(a.images, 300))}" alt="">
      <h1>${esc(a.name)}</h1>
      <div class="muted" style="font-size:13px">${a.artists.map((ar) => `<a href="#/artist/${ar.id}">${esc(ar.name)}</a>`).join(', ')} · ${esc((a.release_date || '').slice(0, 4))} · ${a.total_tracks} canciones</div>
    </div>
    <div class="actions">
      <button class="icon-btn" id="shuf" aria-label="Aleatorio">${icon('shuffle')}</button>
      <span class="spacer"></span>
      <button class="play-btn" data-play='${esc(JSON.stringify({ context_uri: a.uri }))}' aria-label="Reproducir">${icon('play')}</button>
    </div>
    ${tracks.map((t, i) => trackRow(t, { noArt: true, num: t.track_number, play: { context_uri: a.uri, offset: { position: i } } })).join('')}
    ${a.copyrights && a.copyrights[0] ? `<p class="muted" style="font-size:11px;margin-top:20px">${esc(a.copyrights[0].text)}</p>` : ''}`;
  $('#shuf').onclick = () => player.play({ context_uri: a.uri }, true);
}

/* ---------- Artista ---------- */
async function renderArtist(id, token) {
  loading();
  const [a, albums] = await Promise.all([
    api('/artists/' + id),
    api('/artists/' + id + '/albums?include_groups=album,single&limit=20').catch(() => ({ items: [] }))
  ]);
  if (token !== renderToken) return;
  const items = (albums.items || []).filter(Boolean);
  const full = items.filter((x) => x.album_type === 'album');
  const singles = items.filter((x) => x.album_type !== 'album');
  $('#view').innerHTML = `
    ${backBtn()}
    <div class="hero">
      <img class="round" src="${esc(img(a.images, 300))}" alt="">
      <h1>${esc(a.name)}</h1>
      ${a.genres && a.genres.length ? `<div class="muted" style="font-size:13px">${esc(a.genres.slice(0, 3).join(' · '))}</div>` : ''}
    </div>
    <div class="actions">
      <span class="spacer"></span>
      <button class="play-btn" data-play='${esc(JSON.stringify({ context_uri: a.uri }))}' aria-label="Reproducir">${icon('play')}</button>
    </div>
    ${full.length ? '<h2>Álbumes</h2><div class="shelf">' + full.map((x) => tile(x, 'album')).join('') + '</div>' : ''}
    ${singles.length ? '<h2>Sencillos y EP</h2><div class="shelf">' + singles.map((x) => tile(x, 'album')).join('') + '</div>' : ''}`;
}

/* ---------- Canciones que te gustan ---------- */
async function renderLiked(_, token) {
  loading();
  const page = await api('/me/tracks?limit=50');
  if (token !== renderToken) return;
  let all = page.items.map((i) => i.track).filter(Boolean);
  // Para reproducir en orden se envía la lista de URIs (máx. 100 a la vez)
  const playFrom = (i) => ({ uris: all.slice(i, i + 100).map((t) => t.uri) });
  const rows = (list, start) => list.map((t, i) => trackRow(t, { play: playFrom(start + i) })).join('');
  $('#view').innerHTML = `
    ${backBtn()}
    <div class="hero">${likedArt(220)}<h1>Canciones que te gustan</h1><div class="muted" style="font-size:13px">${page.total} canciones</div></div>
    <div class="actions">
      <button class="icon-btn" id="shuf" aria-label="Aleatorio">${icon('shuffle')}</button>
      <span class="spacer"></span>
      <button class="play-btn" id="playAll" aria-label="Reproducir">${icon('play')}</button>
    </div>
    <div id="lkRows">${rows(all, 0)}</div>
    ${page.next ? '<button id="lkMore" class="btn ghost more">Cargar más</button>' : ''}`;
  $('#playAll').onclick = () => all.length && player.play(playFrom(0));
  $('#shuf').onclick = () => all.length && player.play(playFrom(0), true);
  let next = page.next;
  const more = $('#lkMore');
  if (more) more.onclick = async () => {
    more.textContent = 'Cargando…';
    const d = await api(next);
    const start = all.length;
    const added = d.items.map((i) => i.track).filter(Boolean);
    all = all.concat(added);
    $('#lkRows').insertAdjacentHTML('beforeend', rows(added, start));
    next = d.next;
    if (!next) more.remove(); else more.textContent = 'Cargar más';
  };
}

/* ---------- Ajustes ---------- */
async function renderSettings(_, token) {
  if (!me) me = await api('/me').catch(() => null);
  if (token !== renderToken) return;
  $('#view').innerHTML = `
    ${backBtn()}
    <h1>Ajustes</h1>
    ${me ? `<div class="row"><img class="round" src="${esc(img(me.images, 64))}" alt=""><div class="txt"><div class="t">${esc(me.display_name || me.id)}</div><div class="s muted">Sesión iniciada</div></div></div>` : ''}
    <h2>Dispositivo</h2>
    <p class="muted">La música suena en la app oficial de Spotify. Si no encuentra tu móvil, abre Spotify un momento y vuelve a Onda.</p>
    <button class="btn ghost" id="pickDev">Elegir dispositivo</button>
    <button class="btn ghost" id="openSp" style="margin-left:8px">Abrir Spotify</button>
    <h2>Cuenta</h2>
    <p class="muted" style="font-size:13px">Client ID: <code>${esc(store.get('clientId'))}</code></p>
    <button class="btn ghost" id="out">Cerrar sesión</button>
    <button class="btn ghost" id="reset" style="margin-left:8px">Cambiar Client ID</button>
    <p class="muted" style="font-size:12px;margin-top:28px">Onda 1.0 · Reproductor personal. No es un producto de Spotify. Contenido y metadatos de Spotify.</p>`;
  $('#pickDev').onclick = () => player.showDevices();
  $('#openSp').onclick = () => openSpotify('');
  $('#out').onclick = logout;
  $('#reset').onclick = () => { store.del('clientId'); logout(); };
}

/* ---------- Reproductor (Spotify Connect) ---------- */
const player = {
  state: null,
  fetchedAt: 0,
  liked: null,
  likedFor: null,
  seeking: false,

  async refresh() {
    try {
      const s = await api('/me/player?additional_types=track,episode');
      this.state = s && s.item ? s : (s && s.device ? s : null);
      this.fetchedAt = Date.now();
      if (this.state && this.state.device && this.state.device.id) store.set('deviceId', this.state.device.id);
      this.render();
      this.checkLiked();
    } catch (e) { /* silencioso: se reintenta en el siguiente ciclo */ }
  },

  position() {
    const s = this.state;
    if (!s) return 0;
    const p = (s.progress_ms || 0) + (s.is_playing ? Date.now() - this.fetchedAt : 0);
    return Math.min(p, (s.item && s.item.duration_ms) || p);
  },

  async device() {
    if (this.state && this.state.device && this.state.device.id && this.state.device.is_active) return this.state.device.id;
    const d = await api('/me/player/devices');
    const list = (d && d.devices || []).filter((x) => !x.is_restricted);
    const saved = store.get('deviceId');
    const pick = list.find((x) => x.is_active) || list.find((x) => x.id === saved) || list.find((x) => x.type === 'Smartphone') || list[0];
    return pick ? pick.id : null;
  },

  async play(body, shuffle) {
    try {
      let id = await this.device();
      if (!id) {
        // Despierta la app de Spotify y vuelve a mirar
        this.noDevice();
        return;
      }
      if (shuffle !== undefined) await api('/me/player/shuffle?state=' + (shuffle ? 'true' : 'false') + '&device_id=' + id, { method: 'PUT' }).catch(() => {});
      await api('/me/player/play?device_id=' + encodeURIComponent(id), { method: 'PUT', body: body || undefined });
      setTimeout(() => this.refresh(), 600);
      setTimeout(() => this.refresh(), 1800);
    } catch (e) { this.handleError(e); }
  },

  handleError(e) {
    if (e.status === 404 || e.reason === 'NO_ACTIVE_DEVICE') this.noDevice();
    else if (e.status === 403 && (e.reason === 'PREMIUM_REQUIRED' || /premium/i.test(e.message))) toast('Para controlar la reproducción hace falta Spotify Premium.');
    else if (e.status === 403) toast('Spotify no permite esa acción ahora mismo.');
    else if (e.status !== 401) toast('Error: ' + e.message);
  },

  noDevice() {
    sheet(`<h3>No encuentro tu Spotify</h3>
      <p class="muted">Abre la app de Spotify en el móvil un momento (no hace falta darle a reproducir) y vuelve a Onda.</p>
      <div style="display:flex;gap:10px;margin-top:16px">
        <button class="btn" id="wake">Abrir Spotify</button>
        <button class="btn ghost" id="retry">Ya está, reintentar</button>
      </div>`);
    $('#wake').onclick = () => openSpotify('');
    $('#retry').onclick = () => { closeSheet(); this.showDevices(); };
  },

  async showDevices() {
    const d = await api('/me/player/devices').catch((e) => { this.handleError(e); return null; });
    if (!d) return;
    const list = d.devices || [];
    if (!list.length) { this.noDevice(); return; }
    sheet(`<h3>Reproducir en</h3>${list.map((x) => `
      <div class="row" data-dev="${esc(x.id)}">
        <div class="icon-btn ${x.is_active ? 'on' : ''}">${icon('devices')}</div>
        <div class="txt"><div class="t ${x.is_active ? 'link' : ''}">${esc(x.name)}</div><div class="s muted">${esc(x.type)}${x.is_active ? ' · activo' : ''}</div></div>
      </div>`).join('')}`);
    document.querySelectorAll('[data-dev]').forEach((r) => r.onclick = async () => {
      const id = r.getAttribute('data-dev');
      store.set('deviceId', id);
      closeSheet();
      try { await api('/me/player', { method: 'PUT', body: { device_ids: [id], play: true } }); } catch (e) { this.handleError(e); }
      setTimeout(() => this.refresh(), 800);
    });
  },

  async toggle() {
    if (!this.state || !this.state.item) { this.play(null); return; }
    const was = this.state.is_playing;
    this.state.progress_ms = this.position(); this.fetchedAt = Date.now();
    this.state.is_playing = !was; this.render();
    try { await api('/me/player/' + (was ? 'pause' : 'play'), { method: 'PUT' }); }
    catch (e) { this.state.is_playing = was; this.render(); this.handleError(e); }
    setTimeout(() => this.refresh(), 700);
  },
  async cmd(path, method) {
    try { await api(path, { method: method }); } catch (e) { this.handleError(e); }
    setTimeout(() => this.refresh(), 500);
    setTimeout(() => this.refresh(), 1500);
  },
  next() { this.cmd('/me/player/next', 'POST'); },
  prev() {
    if (this.position() > 3000) { this.seek(0); return; }
    this.cmd('/me/player/previous', 'POST');
  },
  seek(ms) {
    if (this.state) { this.state.progress_ms = ms; this.fetchedAt = Date.now(); }
    this.cmd('/me/player/seek?position_ms=' + Math.round(ms), 'PUT');
  },
  shuffle() {
    if (!this.state) return;
    const v = !this.state.shuffle_state;
    this.state.shuffle_state = v; this.render();
    this.cmd('/me/player/shuffle?state=' + v, 'PUT');
  },
  repeat() {
    if (!this.state) return;
    const order = ['off', 'context', 'track'];
    const v = order[(order.indexOf(this.state.repeat_state) + 1) % 3];
    this.state.repeat_state = v; this.render();
    this.cmd('/me/player/repeat?state=' + v, 'PUT');
  },

  async checkLiked() {
    const it = this.state && this.state.item;
    if (!it || it.type !== 'track' || this.likedFor === it.uri) return;
    this.likedFor = it.uri;
    try {
      const r = await api('/me/library/contains?uris=' + encodeURIComponent(it.uri));
      this.liked = Array.isArray(r) ? !!r[0] : null;
    } catch (e) { this.liked = null; }
    this.render();
  },
  async like() {
    const it = this.state && this.state.item;
    if (!it || this.liked === null) return;
    const v = !this.liked;
    this.liked = v; this.render();
    try {
      await api('/me/library?uris=' + encodeURIComponent(it.uri), { method: v ? 'PUT' : 'DELETE' });
      toast(v ? 'Añadida a Canciones que te gustan' : 'Quitada de Canciones que te gustan');
    } catch (e) { this.liked = !v; this.render(); this.handleError(e); }
  },

  render() {
    const s = this.state;
    const it = s && s.item;
    const mini = $('#mini');
    if (!it || document.body.classList.contains('setup-mode')) { mini.classList.add('hidden'); return; }
    mini.classList.remove('hidden');
    const art = img((it.album && it.album.images) || it.images, 300);
    const sub = it.artists ? artists(it.artists) : (it.show && it.show.name) || '';
    if ($('#miniArt').getAttribute('src') !== art) { $('#miniArt').src = art; $('#npArt').src = art; }
    $('#miniTitle').textContent = it.name;
    $('#miniSub').textContent = sub + (s.device && s.device.name ? ' · ' + s.device.name : '');
    $('#miniPlay').innerHTML = icon(s.is_playing ? 'pause' : 'play');
    $('#npPlay').innerHTML = icon(s.is_playing ? 'pause' : 'play');
    $('#npTitle').textContent = it.name;
    $('#npArtist').innerHTML = (it.artists || []).map((a) => `<a href="#/artist/${a.id}">${esc(a.name)}</a>`).join(', ') || esc(sub);
    $('#npShuffle').classList.toggle('on', !!s.shuffle_state);
    $('#npRepeat').classList.toggle('on', s.repeat_state !== 'off');
    $('#npRepeat').innerHTML = icon(s.repeat_state === 'track' ? 'repeatOne' : 'repeat');
    $('#npLike').innerHTML = icon(this.liked ? 'heartFill' : 'heart');
    $('#npLike').classList.toggle('on', !!this.liked);
    $('#npLike').style.visibility = this.liked === null ? 'hidden' : 'visible';
    $('#npDevice').textContent = s.device ? 'En ' + s.device.name : '';
    $('#npContext').textContent = s.context && s.context.type ? ({ playlist: 'Desde una lista', album: 'Desde un álbum', artist: 'Desde un artista', collection: 'Canciones que te gustan' }[s.context.type] || 'Reproduciendo') : 'Reproduciendo';
    document.querySelectorAll('.row[data-id]').forEach((r) => r.classList.toggle('playing', r.getAttribute('data-id') === it.id));
    this.tick();
  },

  tick() {
    const s = this.state;
    if (!s || !s.item) return;
    const dur = s.item.duration_ms || 1;
    const pos = this.position();
    $('#miniBar').style.width = (pos / dur * 100).toFixed(2) + '%';
    if (!this.seeking) $('#npSeek').value = Math.round(pos / dur * 1000);
    $('#npPos').textContent = fmt(pos);
    $('#npDur').textContent = fmt(dur);
    if (s.is_playing && pos >= dur - 300) { this.state.is_playing = false; setTimeout(() => this.refresh(), 800); }
  }
};

/* ---------- Hoja inferior ---------- */
function sheet(html) { $('#sheetCard').innerHTML = html; $('#sheet').classList.remove('hidden'); }
function closeSheet() { $('#sheet').classList.add('hidden'); }
$('#sheet').addEventListener('click', (e) => { if (e.target.id === 'sheet') closeSheet(); });

/* ---------- Pantalla "Reproduciendo" ---------- */
function openNowPlaying() {
  $('#np').classList.remove('hidden');
  if (location.hash.indexOf('np=1') === -1) history.pushState({ np: true }, '', location.hash.split('?')[0] + '?np=1');
}
function closeNowPlaying(fromRoute) {
  const np = $('#np');
  if (np.classList.contains('hidden')) return;
  np.classList.add('hidden');
  if (!fromRoute && location.hash.indexOf('np=1') !== -1) history.back();
}
window.addEventListener('popstate', () => {
  if (location.hash.indexOf('np=1') === -1) $('#np').classList.add('hidden');
});

/* ---------- Bucle de actualización ---------- */
let pollTimer = null;
let tickTimer = null;
function startPolling() {
  stopPolling();
  player.refresh();
  pollTimer = setInterval(() => { if (!document.hidden) player.refresh(); }, 3000);
  tickTimer = setInterval(() => player.tick(), 500);
}
function stopPolling() { clearInterval(pollTimer); clearInterval(tickTimer); pollTimer = tickTimer = null; }
document.addEventListener('visibilitychange', () => { if (!document.hidden && pollTimer) player.refresh(); });

/* ---------- Arranque ---------- */
function wireStatic() {
  document.querySelectorAll('[data-icon]').forEach((el) => { el.innerHTML = icon(el.dataset.icon); });
  $('#npClose').innerHTML = icon('down');
  $('#npDevices').innerHTML = icon('devices');
  $('#npPrev').innerHTML = icon('prev');
  $('#npNext').innerHTML = icon('next');
  $('#npShuffle').innerHTML = icon('shuffle');
  $('#npRepeat').innerHTML = icon('repeat');
  $('#mini').addEventListener('click', (e) => { if (!e.target.closest('#miniPlay')) openNowPlaying(); });
  $('#miniPlay').onclick = (e) => { e.stopPropagation(); player.toggle(); };
  $('#npClose').onclick = () => closeNowPlaying();
  $('#npPlay').onclick = () => player.toggle();
  $('#npNext').onclick = () => player.next();
  $('#npPrev').onclick = () => player.prev();
  $('#npShuffle').onclick = () => player.shuffle();
  $('#npRepeat').onclick = () => player.repeat();
  $('#npLike').onclick = () => player.like();
  $('#npDevices').onclick = () => player.showDevices();
  $('#npArtist').addEventListener('click', (e) => { if (e.target.closest('a')) $('#np').classList.add('hidden'); });
  $('#npOpen').onclick = (e) => { e.preventDefault(); const it = player.state && player.state.item; openSpotify(it ? it.uri : ''); };
  const seek = $('#npSeek');
  seek.addEventListener('input', () => {
    player.seeking = true;
    const dur = (player.state && player.state.item && player.state.item.duration_ms) || 0;
    $('#npPos').textContent = fmt(seek.value / 1000 * dur);
  });
  seek.addEventListener('change', () => {
    const dur = (player.state && player.state.item && player.state.item.duration_ms) || 0;
    player.seeking = false;
    player.seek(seek.value / 1000 * dur);
  });
}

window.addEventListener('hashchange', () => {
  if (location.hash.indexOf('np=1') !== -1) return;
  if ((location.hash || '#/home') === currentRoute) return; // solo se cerró "Reproduciendo"
  route();
});

(async function start() {
  wireStatic();
  const stop = await handleCallback();
  if (stop) return;
  if (!store.get('refresh')) { renderSetup(); return; }
  startPolling();
  route();
})();
